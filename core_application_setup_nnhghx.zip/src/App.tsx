import { Authenticated, Unauthenticated } from "convex/react";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import Calendar from "./components/Calendar";
import Analytics from "./components/Analytics";
import Timer from "./components/Timer";
import { useState } from "react";

export default function App() {
  const [view, setView] = useState<"calendar" | "analytics">("calendar");

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">Time Tracker</h2>
        <div className="flex items-center gap-4">
          <Authenticated>
            <nav className="flex gap-4">
              <button
                onClick={() => setView("calendar")}
                className={`px-4 py-2 rounded ${
                  view === "calendar" ? "bg-indigo-100 text-indigo-700" : ""
                }`}
              >
                Calendar
              </button>
              <button
                onClick={() => setView("analytics")}
                className={`px-4 py-2 rounded ${
                  view === "analytics" ? "bg-indigo-100 text-indigo-700" : ""
                }`}
              >
                Analytics
              </button>
            </nav>
          </Authenticated>
          <SignOutButton />
        </div>
      </header>
      
      <main className="flex-1 p-8">
        <Authenticated>
          <div className="max-w-7xl mx-auto">
            <Timer />
            {view === "calendar" ? <Calendar /> : <Analytics />}
          </div>
        </Authenticated>
        <Unauthenticated>
          <div className="max-w-md mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold mb-4">Welcome to Time Tracker</h1>
              <p className="text-gray-600">Sign in to start managing your time effectively</p>
            </div>
            <SignInForm />
          </div>
        </Unauthenticated>
      </main>
      <Toaster />
    </div>
  );
}
