import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Line, Pie } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  ArcElement
);

export default function Analytics() {
  const startTime = new Date();
  startTime.setDate(startTime.getDate() - 7);
  
  const stats = useQuery(api.timeEntries.getStats, {
    startTime: startTime.getTime(),
    endTime: Date.now(),
  });

  if (!stats) {
    return <div>Loading...</div>;
  }

  const categories = Object.keys(stats.categoryStats);
  const timeSpent = Object.values(stats.categoryStats);

  const pieData = {
    labels: categories,
    datasets: [
      {
        data: timeSpent.map((time) => time / (60 * 60 * 1000)), // Convert to hours
        backgroundColor: [
          "#FF6384",
          "#36A2EB",
          "#FFCE56",
          "#4BC0C0",
          "#9966FF",
        ],
      },
    ],
  };

  // Group entries by day for the line chart
  const dailyData: Record<string, number> = {};
  const days = Array.from({ length: 7 }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - i);
    return date.toISOString().split("T")[0];
  }).reverse();

  days.forEach((day) => {
    dailyData[day] = 0;
  });

  stats.entries.forEach((entry) => {
    if (entry.duration) {
      const day = new Date(entry.startTime).toISOString().split("T")[0];
      dailyData[day] = (dailyData[day] || 0) + entry.duration / (60 * 60 * 1000);
    }
  });

  const lineData = {
    labels: Object.keys(dailyData),
    datasets: [
      {
        label: "Hours per Day",
        data: Object.values(dailyData),
        fill: false,
        borderColor: "rgb(75, 192, 192)",
        tension: 0.1,
      },
    ],
  };

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Time by Category</h3>
          <Pie data={pieData} />
        </div>
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold mb-4">Daily Trends</h3>
          <Line data={lineData} />
        </div>
      </div>
      
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold mb-4">Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-500">Total Time</div>
            <div className="text-2xl font-semibold">
              {(stats.totalTime / (60 * 60 * 1000)).toFixed(1)}h
            </div>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-500">Categories</div>
            <div className="text-2xl font-semibold">{categories.length}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
