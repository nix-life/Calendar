import { useState, useEffect } from "react";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

export default function Timer() {
  const [description, setDescription] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("");
  const [activeTimer, setActiveTimer] = useState<{
    id: Id<"timeEntries">;
    startTime: number;
  } | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);

  const categories = useQuery(api.categories.list);
  const startTimer = useMutation(api.timeEntries.startTimer);
  const stopTimer = useMutation(api.timeEntries.stopTimer);

  useEffect(() => {
    if (categories && categories.length > 0 && !selectedCategory) {
      setSelectedCategory(categories[0].name);
    }
  }, [categories, selectedCategory]);

  useEffect(() => {
    let interval: number;
    if (activeTimer) {
      interval = window.setInterval(() => {
        setElapsedTime(Date.now() - activeTimer.startTime);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [activeTimer]);

  const handleStart = async () => {
    if (!description || !selectedCategory) {
      toast.error("Please fill in all fields");
      return;
    }

    const result = await startTimer({
      description,
      category: selectedCategory,
    });

    setActiveTimer({
      id: result,
      startTime: Date.now(),
    });
    toast.success("Timer started");
  };

  const handleStop = async () => {
    if (!activeTimer) return;

    await stopTimer({
      id: activeTimer.id,
    });
    setActiveTimer(null);
    setElapsedTime(0);
    setDescription("");
    toast.success("Timer stopped");
  };

  const formatTime = (ms: number) => {
    const seconds = Math.floor((ms / 1000) % 60);
    const minutes = Math.floor((ms / 1000 / 60) % 60);
    const hours = Math.floor(ms / 1000 / 60 / 60);

    return `${hours.toString().padStart(2, "0")}:${minutes
      .toString()
      .padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  };

  if (!categories) {
    return <div>Loading...</div>;
  }

  return (
    <div className="bg-white rounded-lg shadow p-6 mb-8">
      <div className="flex flex-col md:flex-row gap-4 items-end">
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            What are you working on?
          </label>
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            disabled={!!activeTimer}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
            placeholder="Task description"
          />
        </div>
        
        <div className="w-full md:w-48">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Category
          </label>
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            disabled={!!activeTimer}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500"
          >
            {categories.map((category) => (
              <option key={category._id} value={category.name}>
                {category.name}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={activeTimer ? handleStop : handleStart}
          className={`px-4 py-2 rounded-md text-white ${
            activeTimer
              ? "bg-red-500 hover:bg-red-600"
              : "bg-indigo-500 hover:bg-indigo-600"
          }`}
        >
          {activeTimer ? "Stop" : "Start"} Timer
        </button>
      </div>

      {activeTimer && (
        <div className="mt-4 text-center">
          <div className="text-3xl font-mono">{formatTime(elapsedTime)}</div>
        </div>
      )}
    </div>
  );
}
