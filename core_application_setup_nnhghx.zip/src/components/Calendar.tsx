import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import { useState } from "react";
import { toast } from "sonner";

export default function Calendar() {
  const [currentRange, setCurrentRange] = useState({
    start: Date.now() - 7 * 24 * 60 * 60 * 1000,
    end: Date.now() + 7 * 24 * 60 * 60 * 1000,
  });

  const events = useQuery(api.events.list, {
    startTime: currentRange.start,
    endTime: currentRange.end,
  });

  const createEvent = useMutation(api.events.create);
  const updateEvent = useMutation(api.events.update);
  const deleteEvent = useMutation(api.events.remove);
  const categories = useQuery(api.categories.list);

  const handleDateSelect = async (selectInfo: any) => {
    const title = prompt("Enter event title");
    if (!title) return;

    const category = categories?.[0]?.name ?? "Default";
    const color = categories?.[0]?.color ?? "#3B82F6";

    await createEvent({
      title,
      start: selectInfo.start.getTime(),
      end: selectInfo.end.getTime(),
      category,
      color,
    });
    toast.success("Event created");
  };

  const handleEventDrop = async (dropInfo: any) => {
    await updateEvent({
      id: dropInfo.event.id,
      start: dropInfo.event.start.getTime(),
      end: dropInfo.event.end.getTime(),
    });
    toast.success("Event updated");
  };

  const handleEventClick = async (clickInfo: any) => {
    if (confirm("Delete this event?")) {
      await deleteEvent({ id: clickInfo.event.id });
      toast.success("Event deleted");
    }
  };

  if (!events || !categories) {
    return <div>Loading...</div>;
  }

  const calendarEvents = events.map((event) => ({
    id: event._id,
    title: event.title,
    start: new Date(event.start),
    end: new Date(event.end),
    backgroundColor: event.color,
    borderColor: event.color,
  }));

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="timeGridWeek"
        headerToolbar={{
          left: "prev,next today",
          center: "title",
          right: "dayGridMonth,timeGridWeek,timeGridDay",
        }}
        editable={true}
        selectable={true}
        selectMirror={true}
        dayMaxEvents={true}
        events={calendarEvents}
        select={handleDateSelect}
        eventDrop={handleEventDrop}
        eventClick={handleEventClick}
        datesSet={(dateInfo) => {
          setCurrentRange({
            start: dateInfo.start.getTime(),
            end: dateInfo.end.getTime(),
          });
        }}
      />
    </div>
  );
}
