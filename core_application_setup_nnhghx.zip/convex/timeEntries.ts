import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const startTimer = mutation({
  args: {
    description: v.string(),
    category: v.string(),
    eventId: v.optional(v.id("events")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("timeEntries", {
      ...args,
      userId,
      startTime: Date.now(),
      endTime: undefined,
      duration: undefined,
    });
  },
});

export const stopTimer = mutation({
  args: {
    id: v.id("timeEntries"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const entry = await ctx.db.get(args.id);
    if (!entry) throw new Error("Entry not found");

    const endTime = Date.now();
    const duration = endTime - entry.startTime;

    return await ctx.db.patch(args.id, {
      endTime,
      duration,
    });
  },
});

export const getStats = query({
  args: {
    startTime: v.number(),
    endTime: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const entries = await ctx.db
      .query("timeEntries")
      .withIndex("by_user_and_start", (q) =>
        q.eq("userId", userId).gte("startTime", args.startTime)
      )
      .take(1000);

    const categoryStats: Record<string, number> = {};
    let totalTime = 0;

    for (const entry of await entries) {
      if (entry.duration) {
        categoryStats[entry.category] = (categoryStats[entry.category] || 0) + entry.duration;
        totalTime += entry.duration;
      }
    }

    return {
      categoryStats,
      totalTime,
      entries: await entries,
    };
  },
});
