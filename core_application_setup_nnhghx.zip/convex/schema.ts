import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  events: defineTable({
    title: v.string(),
    description: v.optional(v.string()),
    start: v.number(), // Unix timestamp
    end: v.number(), // Unix timestamp
    category: v.string(),
    color: v.string(),
    userId: v.id("users"),
    isCompleted: v.boolean(),
  })
    .index("by_user", ["userId"])
    .index("by_user_and_time", ["userId", "start"]),

  timeEntries: defineTable({
    eventId: v.optional(v.id("events")),
    userId: v.id("users"),
    description: v.string(),
    category: v.string(),
    startTime: v.number(),
    endTime: v.optional(v.number()),
    duration: v.optional(v.number()), // in seconds
  })
    .index("by_user", ["userId"])
    .index("by_user_and_start", ["userId", "startTime"]),

  categories: defineTable({
    name: v.string(),
    color: v.string(),
    userId: v.id("users"),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
